package run.halo.app.content;

public record Content(String raw, String content, String rawType) {
}
