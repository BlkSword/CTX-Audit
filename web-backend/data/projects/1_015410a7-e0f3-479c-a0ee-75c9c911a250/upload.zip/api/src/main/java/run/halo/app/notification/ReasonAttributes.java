package run.halo.app.notification;

import java.util.HashMap;

/**
 * <p>{@link ReasonAttributes} is a map that stores the attributes of the reason.</p>
 *
 * @author guqing
 * @since 2.10.0
 */
public class ReasonAttributes extends HashMap<String, Object> {

}
